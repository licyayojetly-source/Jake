# ViralForge REAL AI V2

Real backend pipeline: upload -> FFmpeg frames/audio -> gpt-transcribe -> GPT-5.6 Terra vision analysis -> JSON report.

Set `OPENAI_API_KEY` on the server. Optional `OPENAI_MODEL=gpt-5.6-terra`.

Run: `npm install` then `npm start`, open `http://localhost:3000`.

Deploy as one Node service. Build: `npm install`. Start: `npm start`.

Maximum upload: 100 MB. The score is a heuristic, not a virality guarantee.
