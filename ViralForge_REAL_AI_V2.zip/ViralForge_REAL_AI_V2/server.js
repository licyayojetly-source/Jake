import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import os from "os";
import path from "path";
import { fileURLToPath } from "url";
import { execFile } from "child_process";
import { promisify } from "util";
import ffmpegPath from "ffmpeg-static";
import OpenAI from "openai";
const execFileAsync=promisify(execFile); const __filename=fileURLToPath(import.meta.url); const __dirname=path.dirname(__filename);
const app=express(),PORT=process.env.PORT||3000,MAX_MB=100;
app.use(cors()); app.use(express.json({limit:"1mb"})); app.use(express.static(path.join(__dirname,"public")));
const upload=multer({dest:os.tmpdir(),limits:{fileSize:MAX_MB*1024*1024},fileFilter:(req,file,cb)=>file.mimetype?.startsWith("video/")?cb(null,true):cb(new Error("Please upload a video file."))});
async function ff(args){return execFileAsync(ffmpegPath,args,{maxBuffer:10*1024*1024});}
async function duration(p){try{await ff(["-i",p,"-f","null","-"]);return 0}catch(e){const s=`${e.stderr||""}\n${e.stdout||""}`,m=s.match(/Duration:\s*(\d+):(\d+):([\d.]+)/);return m?Number(m[1])*3600+Number(m[2])*60+Number(m[3]):0}}
async function frames(p,dir,d){const out=[];for(let i=0;i<8;i++){const t=d?Math.max(0,Math.min(d-.05,d*i/7)):i*1;const f=path.join(dir,`f${i}.jpg`);await ff(["-ss",String(t),"-i",p,"-frames:v","1","-vf","scale=720:-2","-q:v","4","-y",f]);out.push({path:f,seconds:t})}return out}
async function audio(p,dir){const a=path.join(dir,"audio.mp3");try{await ff(["-i",p,"-vn","-ac","1","-ar","16000","-b:a","64k","-y",a]);return a}catch{return null}}
async function transcribe(client,p){if(!p||!fs.existsSync(p))return "";try{const r=await client.audio.transcriptions.create({model:"gpt-transcribe",file:fs.createReadStream(p),prompt:"Short-form social media video. Preserve slang, names, gaming terms, and exact wording."});return r.text||""}catch(e){console.warn("Transcription skipped",e.message);return ""}}
function parseJson(t){const c=String(t).replace(/^```json\s*/i,"").replace(/^```\s*/,"").replace(/\s*```$/i,"").trim(),a=c.indexOf("{"),b=c.lastIndexOf("}");if(a<0||b<a)throw Error("AI did not return valid JSON");return JSON.parse(c.slice(a,b+1))}
async function analyze(client,fsx,trans,d){const content=[{type:"input_text",text:`You are ViralForge, an expert short-form video strategist. Analyze the video using these chronological frames and transcript. Duration: ${d?d.toFixed(2):"unknown"} seconds. Transcript: ${trans||"(no spoken dialogue)"}. Evaluate hook, pacing, visual clarity, retention potential, engagement, text and payoff. Do not claim actual platform performance or guarantee virality. Return ONLY valid JSON: {"score":0,"hook":0,"retention":0,"engagement":0,"summary":"","strongest_moment":"","hooks":["","",""],"caption":"","title":"","editing":["","","",""],"ideas":["","","","",""]}. Scores must be 0-100 and recommendations specific to the observed content.`}];for(const f of fsx){content.push({type:"input_image",image_url:`data:image/jpeg;base64,${fs.readFileSync(f.path,"base64")}`,detail:"low"})}const r=await client.responses.create({model:process.env.OPENAI_MODEL||"gpt-5.6-terra",input:[{role:"user",content}],reasoning:{effort:"low"},text:{verbosity:"medium"}});return parseJson(r.output_text)}
app.get("/api/health",(req,res)=>res.json({ok:true,aiConfigured:Boolean(process.env.OPENAI_API_KEY)}));
app.post("/api/analyze",upload.single("video"),async(req,res)=>{let vp=null,dir=null;try{if(!process.env.OPENAI_API_KEY)return res.status(500).json({error:"OPENAI_API_KEY is not configured."});if(!req.file)return res.status(400).json({error:"No video was uploaded."});vp=req.file.path;dir=fs.mkdtempSync(path.join(os.tmpdir(),"viralforge-"));const d=await duration(vp),fx=await frames(vp,dir,d),ap=await audio(vp,dir),client=new OpenAI({apiKey:process.env.OPENAI_API_KEY}),tr=await transcribe(client,ap),result=await analyze(client,fx,tr,d);res.json({ok:true,analysis:result,meta:{duration:d,frames:fx.length,transcriptAvailable:Boolean(tr)}})}catch(e){console.error(e);res.status(500).json({error:e.message||"Analysis failed."})}finally{if(vp)fs.rm(vp,{force:true},()=>{});if(dir)fs.rm(dir,{recursive:true,force:true},()=>{})}});
app.use((e,req,res,next)=>{if(e instanceof multer.MulterError&&e.code==="LIMIT_FILE_SIZE")return res.status(413).json({error:`Video too large. Maximum ${MAX_MB} MB.`});res.status(400).json({error:e.message||"Request failed."})});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`ViralForge running on ${PORT}`));
